function collectData() {
  const taskInfo = document.querySelector('h4 b') ? document.querySelector('h4 b').innerText : null;
  const workDoneInfo = document.querySelector('.row .col-sm-5 b') ? document.querySelector('.row .col-sm-5 b').innerText : null;


  const jobIdText = document.querySelector('td .row .col-sm-5') ? document.querySelector('td .row .col-sm-5').innerHTML : '';
  const jobIdMatch = jobIdText.match(/Job ID: (\S+)<br>/);
  
  let jobId = jobIdMatch && jobIdMatch[1] ? jobIdMatch[1] : null;


  if (taskInfo && workDoneInfo && jobId) {
    const fullLink = `https://ttv.microworkers.com/dotask/info/${jobId}_HG`;
    
    const data = {
      content: `Task Info: ${taskInfo}\nWork Done Info: ${workDoneInfo}\nJob Link: ${fullLink}`
    };
    localStorage.setItem('webhookData', JSON.stringify(data));
  } else {

    localStorage.removeItem('webhookData');
  }
}

function sendDataToDiscord() {
  const webhookUrl = 'https://discord.com/api/webhooks/1281335156921335840/6YVZ51150DoQYpHzmTxcmmFP6Mq7z5TKMsp2ij-cmyZy2-5GKCfoj6dFsNjvgLNwM5VD';
  
  const data = JSON.parse(localStorage.getItem('webhookData'));

  if (data) {
    fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => {
      if (response.ok) {
        console.log('Data sent to Discord successfully!');
      } else {
        console.error('Error sending data to Discord:', response.statusText);
      }
    })
    .catch(error => console.error('Fetch error:', error))
    .finally(() => {
      localStorage.removeItem('webhookData'); 
    });
  }
}


window.addEventListener('beforeunload', collectData);


window.addEventListener('load', () => {

  const randomDelay = Math.floor(Math.random() * (5000 - 2000 + 1)) + 2000; 
  setTimeout(sendDataToDiscord, randomDelay);
});
